// Ejemplo sencillo, con dos errores semanticos,
// del uso de la instruccion "countdown"
int main () {
  int a[10]; int i; 

  countdown i = false step 2 do a[i] = i;
  countdown i = 8 step true do print(a[i]);
  
  return 0;
}
