// Ejemplo sencillo, sin errores, del uso de la
// instruccion "countdown". Salida: 8 6 4 2 0 
int main () {
  int a[10]; int i; 

  countdown i = 8 step 2 do a[i] = i;
  countdown i = 8 step 2 do print(a[i]);

  return 0;
}
